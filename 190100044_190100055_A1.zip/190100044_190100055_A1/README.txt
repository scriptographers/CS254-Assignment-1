Team Members:
1. Devansh Jain  (190100044)
2. Harshit Varma (190100055)

All the three basic logic gates (NOT, OR, AND) are designed in one entity named BasicLogicGate present in "BasicLogicGate.vhd"

The testbench code is present in "Testbench.vhd"

The simulation output is present as a image file named "simulation.jpg"
The simulation output is also printed as a PDF in the file "simulation.pdf"

