Team Members:
1. Devansh Jain  (190100044)
2. Harshit Varma (190100055)

All the three basic logic gates (NOT, OR, AND) are designed in one entity named BasicLogicGate present in "BasicLogicGate.vhd"
The testbench code is present in TestBench.vhd

The simulation output is present as a image file named "sim_output.png".

