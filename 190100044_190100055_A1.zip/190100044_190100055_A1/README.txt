CS 254: Assignment 1

Team Members:
1. Devansh Jain  (190100044)
2. Harshit Varma (190100055)

File Descriptions:
1. BasicLogicGate.vhd : Contains all the three basic logic gates (NOT, OR, AND) are designed in one entity named BasicLogicGate
2. Testbench.vhd : Contains code for the testbench
3. simulation.jpg : Image/Screenshot of the simulation results
4. simulation.pdf : Simulation results printed as a PDF

